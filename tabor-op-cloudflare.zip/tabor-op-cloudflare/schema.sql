-- طابور — إنشاء كل جداول النظام دفعة واحدة
-- انسخ هذا الملف كاملاً والصقه في محرّر SQL داخل Neon ثم شغّله

-- ═══ 20260803153521_create_required_reports ═══
CREATE TABLE "required_reports" (
	"id" serial PRIMARY KEY,
	"role" text NOT NULL,
	"frequency" text NOT NULL,
	"title" text NOT NULL,
	"icon" text DEFAULT '📄' NOT NULL,
	"due_weekday" integer DEFAULT 6 NOT NULL,
	"due_day" integer DEFAULT 5 NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE INDEX "required_reports_role_idx" ON "required_reports" ("role","frequency");

-- ═══ 20260804133301_create_tasks_and_branches ═══
CREATE TABLE "branches" (
	"id" serial PRIMARY KEY,
	"branch_id" text NOT NULL,
	"region" text NOT NULL,
	"name" text NOT NULL,
	"supervisor" text DEFAULT '' NOT NULL,
	"lat" double precision NOT NULL,
	"lng" double precision NOT NULL,
	"radius" integer DEFAULT 150 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "daily_tasks" (
	"id" serial PRIMARY KEY,
	"role" text NOT NULL,
	"title" text NOT NULL,
	"icon" text DEFAULT '📌' NOT NULL,
	"category" text DEFAULT 'عام' NOT NULL,
	"period" text DEFAULT 'anytime' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "urgent_tasks" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"details" text DEFAULT '' NOT NULL,
	"priority" text DEFAULT 'متوسط' NOT NULL,
	"status" text DEFAULT 'جديد' NOT NULL,
	"target_role" text NOT NULL,
	"region" text DEFAULT '' NOT NULL,
	"branch" text DEFAULT '' NOT NULL,
	"due_date" text DEFAULT '' NOT NULL,
	"created_by_role" text NOT NULL,
	"created_by_name" text DEFAULT '' NOT NULL,
	"updated_by_name" text DEFAULT '' NOT NULL,
	"completed_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE UNIQUE INDEX "branches_branch_id_idx" ON "branches" ("branch_id");
CREATE INDEX "daily_tasks_role_idx" ON "daily_tasks" ("role","sort_order");
CREATE INDEX "urgent_tasks_target_idx" ON "urgent_tasks" ("target_role","status");

-- ═══ 20260804163248_create_menu_and_completions ═══
CREATE TABLE "menu_items" (
	"id" serial PRIMARY KEY,
	"item_key" text NOT NULL,
	"label" text NOT NULL,
	"roles" text DEFAULT '' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "task_completions" (
	"id" serial PRIMARY KEY,
	"scope_id" text NOT NULL,
	"role" text NOT NULL,
	"task_id" text NOT NULL,
	"day" text NOT NULL,
	"done_by_name" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE UNIQUE INDEX "menu_items_key_idx" ON "menu_items" ("item_key");
CREATE UNIQUE INDEX "task_completions_unique_idx" ON "task_completions" ("scope_id","task_id","day");
CREATE INDEX "task_completions_day_idx" ON "task_completions" ("day");

-- ═══ 20260809144114_create_visits ═══
CREATE TABLE "app_settings" (
	"id" serial PRIMARY KEY,
	"setting_key" text NOT NULL,
	"setting_value" text DEFAULT '' NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "visit_files" (
	"id" serial PRIMARY KEY,
	"visit_id" integer NOT NULL,
	"name" text DEFAULT 'مرفق' NOT NULL,
	"mime" text DEFAULT 'image/jpeg' NOT NULL,
	"size" integer DEFAULT 0 NOT NULL,
	"caption" text DEFAULT '' NOT NULL,
	"data" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "visit_items" (
	"id" serial PRIMARY KEY,
	"section" text DEFAULT 'عام' NOT NULL,
	"title" text NOT NULL,
	"type" text DEFAULT 'check' NOT NULL,
	"weight" integer DEFAULT 1 NOT NULL,
	"required" boolean DEFAULT false NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE "visits" (
	"id" serial PRIMARY KEY,
	"branch_id" text NOT NULL,
	"branch_name" text DEFAULT '' NOT NULL,
	"region" text DEFAULT '' NOT NULL,
	"visitor_name" text DEFAULT '' NOT NULL,
	"visitor_role" text DEFAULT '' NOT NULL,
	"day" text NOT NULL,
	"month" text NOT NULL,
	"started_at" timestamp DEFAULT now() NOT NULL,
	"submitted_at" timestamp,
	"lat" double precision NOT NULL,
	"lng" double precision NOT NULL,
	"distance" integer DEFAULT 0 NOT NULL,
	"score" integer DEFAULT 0 NOT NULL,
	"results" text DEFAULT '[]' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"actions" text DEFAULT '' NOT NULL,
	"supervisor_name" text DEFAULT '' NOT NULL,
	"sent_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);

CREATE UNIQUE INDEX "app_settings_key_idx" ON "app_settings" ("setting_key");
CREATE INDEX "visit_files_visit_idx" ON "visit_files" ("visit_id");
CREATE INDEX "visit_items_order_idx" ON "visit_items" ("sort_order");
CREATE INDEX "visits_branch_month_idx" ON "visits" ("branch_id","month");
CREATE INDEX "visits_month_idx" ON "visits" ("month");
