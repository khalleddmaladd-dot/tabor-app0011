import { initDb } from "../db/index.js";

import { handle as branches } from "./handlers/branches.js";
import { handle as dailyTasks } from "./handlers/daily-tasks.js";
import { handle as menu } from "./handlers/menu.js";
import { handle as requiredReports } from "./handlers/required-reports.js";
import { handle as taskCompletions } from "./handlers/task-completions.js";
import { handle as urgentTasks } from "./handlers/urgent-tasks.js";
import { handle as visitFiles } from "./handlers/visit-files.js";
import { handle as visitItems } from "./handlers/visit-items.js";
import { handle as visits } from "./handlers/visits.js";

/** ما يصل إلى كل معالج: معاملات المسار (قاعدة البيانات تُستورد مباشرة) */
export type Ctx = {
  params: Record<string, string>;
};

type Handler = (req: Request, ctx: Ctx) => Promise<Response>;

/** المسار الأول بعد /api/ → المعالج المسؤول عنه */
const ROUTES: Record<string, Handler> = {
  "required-reports": requiredReports,
  "daily-tasks": dailyTasks,
  "urgent-tasks": urgentTasks,
  "task-completions": taskCompletions,
  branches,
  menu,
  visits,
  "visit-items": visitItems,
  "visit-files": visitFiles,
};

/**
 * موجّه واحد لكل مسارات /api/*
 *
 * /api/daily-tasks        → params.id = ""
 * /api/daily-tasks/12     → params.id = "12"
 * /api/menu/reorder       → params.id = "reorder"
 */
export async function route(req: Request, databaseUrl: string) {
  const url = new URL(req.url);
  const segments = url.pathname.split("/").filter(Boolean); // ["api", "daily-tasks", "12"]

  if (segments[0] !== "api" || segments.length < 2) {
    return Response.json({ error: "مسار غير معروف" }, { status: 404 });
  }

  const handler = ROUTES[segments[1]];
  if (!handler) {
    return Response.json({ error: "مسار غير معروف" }, { status: 404 });
  }

  try {
    initDb(databaseUrl);
    const res = await handler(req, { params: { id: segments[2] ?? "" } });
    // منع تخزين استجابات الـ API في الكاش
    const headers = new Headers(res.headers);
    headers.set("cache-control", "no-store");
    return new Response(res.body, { status: res.status, headers });
  } catch (error) {
    console.error("route failed", segments.join("/"), error);
    return Response.json({ error: "تعذّر تنفيذ الطلب" }, { status: 500 });
  }
}
