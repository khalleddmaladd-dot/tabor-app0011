import type { Ctx } from "../router.js";
import { asc, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { menuItems } from "../../db/schema.js";
import { ROLES, identityOf, isAdmin } from "../hierarchy.js";

/**
 * القائمة الرئيسية — ترتيب وتسمية وإظهار الشاشات
 *
 * GET   /api/menu             → قراءة القائمة (تُزرع من الافتراضيات عند أول تشغيل)
 * PUT   /api/menu/:id         → تعديل عنصر (الاسم / الإظهار / المناصب)   — مدير النظام
 * POST  /api/menu/reorder     → إعادة ترتيب القائمة بإرسال { keys: [...] } — مدير النظام
 * POST  /api/menu/reset       → استعادة الترتيب والتسميات الافتراضية      — مدير النظام
 *
 * الشاشات ثابتة في التطبيق؛ هذا الجدول يخزّن التخصيص فوقها فقط.
 */

const ALL = "";
const NO_CASHIER = "ops_manager,area_manager,branch_manager";
const OPS_ONLY = "ops_manager";

type Seed = [key: string, label: string, roles: string];

const SEEDS: Seed[] = [
  ["dashboard", "📊 لوحة التحكم", ALL],
  ["tasks", "✅ مهامي", ALL],
  ["reports_req", "📑 التقارير المطلوبة", ALL],
  ["urgent", "⚡ مهام مستعجلة", ALL],
  ["tracking", "👥 متابعة المرؤوسين", NO_CASHIER],
  ["visits", "📍 زيارات الفروع", NO_CASHIER],
  ["attendance", "📅 حضور الموظفين", NO_CASHIER],
  ["am_schedule", "🗓️ جدول مدراء المناطق", NO_CASHIER],
  ["haccp", "🧪 سلامة الغذاء", NO_CASHIER],
  ["delivery", "💰 المبيعات", NO_CASHIER],
  ["customers", "⭐ تجربة العميل", NO_CASHIER],
  ["maintenance", "🔧 طلبات الصيانة", NO_CASHIER],
  ["op_guides", "📖 الدليل التشغيلي", ALL],
  ["circulars", "📢 التعاميم", ALL],
  ["export_reports", "⬇️ تصدير التقارير", ALL],
  ["admin", "⚙️ إدارة النظام", OPS_ONLY],
];

function seedRows() {
  return SEEDS.map(([itemKey, label, roles], i) => ({
    itemKey,
    label,
    roles,
    sortOrder: i,
    active: true,
  }));
}

function cleanRoles(value: unknown) {
  const list = String(value ?? "")
    .split(",")
    .map((r) => r.trim())
    .filter((r) => ROLES.includes(r));
  // كل المناصب مختارة = بلا قيد
  return list.length === 0 || list.length === ROLES.length ? "" : [...new Set(list)].join(",");
}

async function readAll() {
  let rows = await db.select().from(menuItems).orderBy(asc(menuItems.sortOrder), asc(menuItems.id));

  if (rows.length === 0) {
    await db.insert(menuItems).values(seedRows());
    rows = await db.select().from(menuItems).orderBy(asc(menuItems.sortOrder), asc(menuItems.id));
    return rows;
  }

  // شاشات أُضيفت بعد الزرع الأول تُلحق تلقائياً في نهاية القائمة
  const known = new Set(rows.map((row) => row.itemKey));
  const missing = seedRows().filter((row) => !known.has(row.itemKey));
  if (missing.length) {
    await db.insert(menuItems).values(missing.map((row, i) => ({ ...row, sortOrder: rows.length + i })));
    rows = await db.select().from(menuItems).orderBy(asc(menuItems.sortOrder), asc(menuItems.id));
  }

  return rows;
}

export async function handle(req: Request, ctx: Ctx) {
  const param = String(ctx.params.id ?? "");
  const identity = identityOf(req);

  try {
    if (req.method === "GET") {
      return Response.json({ items: await readAll() }, { headers: { "cache-control": "no-store" } });
    }

    if (!isAdmin(identity)) {
      return Response.json({ error: "تعديل القائمة متاح لمدير النظام فقط" }, { status: 403 });
    }

    if (req.method === "POST" && param === "reset") {
      await db.delete(menuItems);
      await db.insert(menuItems).values(seedRows());
      return Response.json({ items: await readAll() });
    }

    if (req.method === "POST" && param === "reorder") {
      const body = (await req.json()) as Record<string, unknown>;
      const keys = Array.isArray(body.keys) ? body.keys.map(String) : [];
      if (keys.length === 0) return Response.json({ error: "الترتيب الجديد مطلوب" }, { status: 400 });

      for (let i = 0; i < keys.length; i++) {
        await db
          .update(menuItems)
          .set({ sortOrder: i, updatedAt: new Date() })
          .where(eq(menuItems.itemKey, keys[i]));
      }

      return Response.json({ items: await readAll() });
    }

    if (req.method === "PUT") {
      const id = Number(param);
      if (!id) return Response.json({ error: "معرّف العنصر مطلوب" }, { status: 400 });

      const body = (await req.json()) as Record<string, unknown>;
      const label = String(body.label ?? "").trim();
      if (!label) return Response.json({ error: "اسم العنصر مطلوب" }, { status: 400 });
      if (label.length > 80) return Response.json({ error: "اسم العنصر طويل جداً" }, { status: 400 });

      const [updated] = await db
        .update(menuItems)
        .set({
          label,
          roles: cleanRoles(body.roles),
          active: body.active === undefined ? true : Boolean(body.active),
          updatedAt: new Date(),
        })
        .where(eq(menuItems.id, id))
        .returning();

      if (!updated) return Response.json({ error: "العنصر غير موجود" }, { status: 404 });
      return Response.json({ item: updated });
    }

    return Response.json({ error: "طريقة غير مدعومة" }, { status: 405 });
  } catch (error) {
    console.error("menu failed", error);
    return Response.json({ error: "تعذّر تنفيذ الطلب" }, { status: 500 });
  }
}
