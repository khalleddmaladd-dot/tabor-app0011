import type { Ctx } from "../router.js";
import { and, eq, gte, lte } from "drizzle-orm";
import { db } from "../../db/index.js";
import { taskCompletions } from "../../db/schema.js";
import { ROLES, identityOf } from "../hierarchy.js";

/**
 * إنجاز المهام اليومية — مصدر النسب في «متابعة المرؤوسين»
 *
 * GET  /api/task-completions?from=YYYY-MM-DD&to=YYYY-MM-DD → سجلّ الإنجاز في المدى
 * POST /api/task-completions → تعليم مهمة كمنجزة أو إلغاؤها
 *      { scopeId, role, taskId, day, done }
 *
 * الحفظ على الخادم هو ما يجعل المدير يرى إنجاز مرؤوسيه لحظياً.
 */

const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;

function today() {
  return new Date().toISOString().split("T")[0];
}

function shiftDays(day: string, delta: number) {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + delta);
  return d.toISOString().split("T")[0];
}

export async function handle(req: Request, ctx: Ctx) {
  const identity = identityOf(req);

  if (!identity.role) {
    return Response.json({ error: "هوية المستخدم غير معروفة" }, { status: 401 });
  }

  try {
    if (req.method === "GET") {
      const url = new URL(req.url);
      const to = DAY_RE.test(url.searchParams.get("to") ?? "") ? url.searchParams.get("to")! : today();
      const fromParam = url.searchParams.get("from");
      const from = DAY_RE.test(fromParam ?? "") ? fromParam! : shiftDays(to, -29);

      const rows = await db
        .select()
        .from(taskCompletions)
        .where(and(gte(taskCompletions.day, from), lte(taskCompletions.day, to)));

      return Response.json({ completions: rows, from, to }, { headers: { "cache-control": "no-store" } });
    }

    if (req.method === "POST") {
      const body = (await req.json()) as Record<string, unknown>;
      const scopeId = String(body.scopeId ?? "").trim().slice(0, 40);
      const taskId = String(body.taskId ?? "").trim().slice(0, 40);
      const role = ROLES.includes(String(body.role)) ? String(body.role) : "";
      const day = DAY_RE.test(String(body.day ?? "")) ? String(body.day) : today();
      const done = Boolean(body.done);

      if (!scopeId || !taskId) return Response.json({ error: "بيانات المهمة ناقصة" }, { status: 400 });
      if (!role) return Response.json({ error: "المنصب غير صحيح" }, { status: 400 });
      if (day !== today()) return Response.json({ error: "لا يمكن تعديل إنجاز يوم سابق" }, { status: 400 });

      const where = and(
        eq(taskCompletions.scopeId, scopeId),
        eq(taskCompletions.taskId, taskId),
        eq(taskCompletions.day, day),
      );

      if (!done) {
        await db.delete(taskCompletions).where(where);
        return Response.json({ done: false });
      }

      const [existing] = await db.select().from(taskCompletions).where(where);
      if (existing) return Response.json({ done: true, completion: existing });

      const [created] = await db
        .insert(taskCompletions)
        .values({ scopeId, role, taskId, day, doneByName: identity.name })
        .returning();

      return Response.json({ done: true, completion: created }, { status: 201 });
    }

    return Response.json({ error: "طريقة غير مدعومة" }, { status: 405 });
  } catch (error) {
    console.error("task-completions failed", error);
    return Response.json({ error: "تعذّر تنفيذ الطلب" }, { status: 500 });
  }
}
