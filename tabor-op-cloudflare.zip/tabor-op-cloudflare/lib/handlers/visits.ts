import type { Ctx } from "../router.js";
import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "../../db/index.js";
import { appSettings, branches, visitFiles, visits } from "../../db/schema.js";
import { identityOf, isAdmin } from "../hierarchy.js";

/**
 * زيارات الفروع
 *
 * GET    /api/visits?month=YYYY-MM → الزيارات + الإعدادات (حسب نطاق المستخدم)
 * POST   /api/visits               → تسجيل زيارة — يُرفض خارج نطاق الفرع الجغرافي
 * PUT    /api/visits/:id           → تعديل الإجراءات المتخذة أو تعليم التقرير كمُرسَل
 * DELETE /api/visits/:id           → حذف زيارة (كاتبها أو مدير النظام)
 *
 * قاعدة أساسية: لا يُكتب تقرير زيارة إلا من داخل موقع الفرع. الخادم يحسب المسافة
 * بين إحداثيات كاتب التقرير وإحداثيات الفرع المسجّلة، ويرفض ما تجاوز نطاق الفرع.
 */

const MAX_FILES = 8;
const MAX_FILE_BYTES = 900_000; // ~900KB بعد الضغط في المتصفح
const GEO_TOLERANCE = 50; // هامش تسامح بالأمتار لدقة GPS

/** المسافة بالأمتار بين نقطتين (Haversine) */
function distanceMeters(lat1: number, lng1: number, lat2: number, lng2: number) {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

function monthOf(day: string) {
  return day.slice(0, 7);
}

function todayIso() {
  return new Date().toISOString().split("T")[0];
}

async function visitsPerMonth() {
  const [row] = await db.select().from(appSettings).where(eq(appSettings.settingKey, "visits_per_month"));
  const n = Number(row?.settingValue ?? 4);
  return Number.isFinite(n) && n > 0 ? Math.trunc(n) : 4;
}

/** حساب النتيجة من نتائج البنود */
function scoreOf(results: Array<Record<string, unknown>>) {
  let earned = 0;
  let possible = 0;

  for (const r of results) {
    const weight = Number(r.weight) || 0;
    if (r.type === "check") {
      possible += weight;
      if (r.value === true) earned += weight;
    } else if (r.type === "rating") {
      const value = Number(r.value);
      if (Number.isFinite(value) && value > 0) {
        possible += weight * 5;
        earned += weight * Math.min(5, Math.max(0, value));
      }
    }
  }

  return possible ? Math.round((earned / possible) * 100) : 0;
}

export async function handle(req: Request, ctx: Ctx) {
  const id = Number(ctx.params.id ?? 0);
  const identity = identityOf(req);

  if (!identity.role) {
    return Response.json({ error: "هوية المستخدم غير معروفة" }, { status: 401 });
  }

  try {
    if (req.method === "GET") {
      const url = new URL(req.url);
      const since = url.searchParams.get("since") || "";

      const rows = await db
        .select()
        .from(visits)
        .where(since ? gte(visits.day, since) : undefined)
        .orderBy(desc(visits.id))
        .limit(400);

      const mine = rows.filter((row) => {
        if (isAdmin(identity)) return true;
        if (identity.role === "area_manager") return !identity.region || row.region === identity.region;
        return !identity.branch || row.branchId === identity.branch;
      });

      const files = await db
        .select({ id: visitFiles.id, visitId: visitFiles.visitId, name: visitFiles.name, mime: visitFiles.mime })
        .from(visitFiles);

      return Response.json(
        {
          visits: mine.map((row) => ({
            ...row,
            results: JSON.parse(row.results || "[]"),
            fileCount: files.filter((f) => f.visitId === row.id).length,
          })),
          visitsPerMonth: await visitsPerMonth(),
        },
        { headers: { "cache-control": "no-store" } },
      );
    }

    if (req.method === "POST") {
      const body = (await req.json()) as Record<string, unknown>;
      const branchId = String(body.branchId ?? "").trim();
      const lat = Number(body.lat);
      const lng = Number(body.lng);
      const actions = String(body.actions ?? "").trim();
      const results = Array.isArray(body.results) ? (body.results as Array<Record<string, unknown>>) : [];

      if (!branchId) return Response.json({ error: "الفرع مطلوب" }, { status: 400 });
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
        return Response.json({ error: "تعذّر تحديد موقعك — فعّل الموقع وأعد المحاولة" }, { status: 400 });
      }
      if (!actions) {
        return Response.json({ error: "الإجراءات المتخذة إلزامية قبل اعتماد التقرير" }, { status: 400 });
      }
      if (results.length === 0) {
        return Response.json({ error: "لم يتم تعبئة بنود التقييم" }, { status: 400 });
      }

      const [branch] = await db.select().from(branches).where(eq(branches.branchId, branchId));
      if (!branch) {
        return Response.json(
          { error: "الفرع غير مسجّل بموقع جغرافي — أضف موقعه من إدارة النظام أولاً" },
          { status: 400 },
        );
      }

      const distance = distanceMeters(lat, lng, branch.lat, branch.lng);
      const allowed = (branch.radius || 150) + GEO_TOLERANCE;
      if (distance > allowed) {
        return Response.json(
          {
            error: `لا يمكن كتابة التقرير من خارج الفرع — تبعد ${distance} متراً عن ${branch.name} (النطاق المسموح ${allowed} متر)`,
            distance,
          },
          { status: 403 },
        );
      }

      const day = todayIso();
      const [created] = await db
        .insert(visits)
        .values({
          branchId,
          branchName: branch.name,
          region: branch.region,
          visitorName: identity.name,
          visitorRole: identity.role,
          day,
          month: monthOf(day),
          submittedAt: new Date(),
          lat,
          lng,
          distance,
          score: scoreOf(results),
          results: JSON.stringify(results).slice(0, 60_000),
          notes: String(body.notes ?? "").slice(0, 2000),
          actions: actions.slice(0, 2000),
          supervisorName: String(body.supervisorName ?? branch.supervisor ?? "").slice(0, 120),
        })
        .returning();

      // المرفقات تُرسل مع التقرير بعد ضغطها في المتصفح
      const incoming = Array.isArray(body.files) ? (body.files as Array<Record<string, unknown>>) : [];
      const accepted = incoming.slice(0, MAX_FILES).filter((f) => String(f.data ?? "").length <= MAX_FILE_BYTES * 1.4);

      if (accepted.length) {
        await db.insert(visitFiles).values(
          accepted.map((f) => ({
            visitId: created.id,
            name: String(f.name ?? "مرفق").slice(0, 120),
            mime: String(f.mime ?? "image/jpeg").slice(0, 60),
            size: Number(f.size) || 0,
            caption: String(f.caption ?? "").slice(0, 200),
            data: String(f.data ?? ""),
          })),
        );
      }

      return Response.json(
        { visit: { ...created, results }, files: accepted.length, skipped: incoming.length - accepted.length },
        { status: 201 },
      );
    }

    if (!id) return Response.json({ error: "معرّف الزيارة مطلوب" }, { status: 400 });

    const [row] = await db.select().from(visits).where(eq(visits.id, id));
    if (!row) return Response.json({ error: "الزيارة غير موجودة" }, { status: 404 });

    const owns = isAdmin(identity) || row.visitorName === identity.name;

    if (req.method === "PUT") {
      const body = (await req.json()) as Record<string, unknown>;

      if (body.markSent) {
        const [updated] = await db
          .update(visits)
          .set({ sentAt: new Date(), supervisorName: String(body.supervisorName ?? row.supervisorName) })
          .where(eq(visits.id, id))
          .returning();
        return Response.json({ visit: { ...updated, results: JSON.parse(updated.results || "[]") } });
      }

      if (!owns) return Response.json({ error: "تعديل التقرير متاح لكاتبه فقط" }, { status: 403 });

      const actions = String(body.actions ?? "").trim();
      if (!actions) return Response.json({ error: "الإجراءات المتخذة إلزامية" }, { status: 400 });

      const [updated] = await db
        .update(visits)
        .set({ actions: actions.slice(0, 2000), notes: String(body.notes ?? row.notes).slice(0, 2000) })
        .where(eq(visits.id, id))
        .returning();

      return Response.json({ visit: { ...updated, results: JSON.parse(updated.results || "[]") } });
    }

    if (req.method === "DELETE") {
      if (!owns) return Response.json({ error: "حذف التقرير متاح لكاتبه أو لمدير النظام" }, { status: 403 });
      await db.delete(visitFiles).where(eq(visitFiles.visitId, id));
      await db.delete(visits).where(eq(visits.id, id));
      return Response.json({ deleted: id });
    }

    return Response.json({ error: "طريقة غير مدعومة" }, { status: 405 });
  } catch (error) {
    console.error("visits failed", error);
    return Response.json({ error: "تعذّر تنفيذ الطلب" }, { status: 500 });
  }
}
