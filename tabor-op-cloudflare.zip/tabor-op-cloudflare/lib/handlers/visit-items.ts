import type { Ctx } from "../router.js";
import { asc, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { appSettings, visitItems } from "../../db/schema.js";
import { identityOf, isAdmin } from "../hierarchy.js";

/**
 * بنود تقييم الزيارة + إعدادات الزيارات
 *
 * GET    /api/visit-items         → البنود + الإعدادات (تُزرع عند أول تشغيل)
 * POST   /api/visit-items         → إضافة بند            (مدير النظام)
 * PUT    /api/visit-items/:id     → تعديل بند            (مدير النظام)
 * DELETE /api/visit-items/:id     → حذف بند              (مدير النظام)
 * PUT    /api/visit-items/settings→ تعديل الإعدادات       (مدير النظام)
 */

const TYPES = ["check", "rating", "note"];
export const VISITS_PER_MONTH_KEY = "visits_per_month";

type Seed = [section: string, title: string, type: string, weight?: number];

const SEEDS: Seed[] = [
  ["النظافة", "نظافة منطقة العملاء والطاولات", "rating", 2],
  ["النظافة", "نظافة المطبخ وأسطح التحضير", "rating", 3],
  ["النظافة", "نظافة دورات المياه", "rating", 2],
  ["النظافة", "نظافة الثلاجات والمخزن", "rating", 2],
  ["النظافة", "التخلص السليم من النفايات", "check", 1],
  ["سير العمل", "الالتزام بأوقات الافتتاح", "check", 2],
  ["سير العمل", "سرعة تحضير الطلبات", "rating", 3],
  ["سير العمل", "توفر الأصناف في القائمة", "rating", 2],
  ["سير العمل", "حالة المعدات وصلاحيتها للعمل", "rating", 2],
  ["سير العمل", "تطبيق نموذج HACCP اليومي", "check", 2],
  ["سير العمل", "سلامة درجات حرارة التخزين", "check", 3],
  ["الفريق والخدمة", "المظهر العام والزي الرسمي", "rating", 2],
  ["الفريق والخدمة", "الترحيب بالعميل وأسلوب التعامل", "rating", 3],
  ["الفريق والخدمة", "دقة الطلبات والتغليف", "rating", 2],
  ["الفريق والخدمة", "اكتمال عدد الموظفين حسب الجدول", "check", 2],
  ["المخزون والأسعار", "مطابقة الأسعار في التطبيقات", "check", 2],
  ["المخزون والأسعار", "صلاحية المنتجات المعروضة", "check", 3],
  ["المخزون والأسعار", "مستوى المخزون وكفايته", "rating", 2],
  ["ملاحظات", "أبرز الملاحظات على الفرع", "note", 0],
  ["ملاحظات", "نقاط التحسين المقترحة", "note", 0],
];

function seedRows() {
  return SEEDS.map(([section, title, type, weight], i) => ({
    section,
    title,
    type,
    weight: weight ?? 1,
    required: type !== "note",
    sortOrder: i,
    active: true,
  }));
}

async function readSettings() {
  const rows = await db.select().from(appSettings);
  const map: Record<string, string> = {};
  rows.forEach((row) => (map[row.settingKey] = row.settingValue));

  if (!map[VISITS_PER_MONTH_KEY]) {
    map[VISITS_PER_MONTH_KEY] = "4";
    await db
      .insert(appSettings)
      .values({ settingKey: VISITS_PER_MONTH_KEY, settingValue: "4" })
      .onConflictDoNothing();
  }

  return map;
}

function parseBody(body: Record<string, unknown>) {
  const title = String(body.title ?? "").trim();
  if (!title) return { error: "عنوان البند مطلوب" as const };
  if (title.length > 160) return { error: "عنوان البند طويل جداً" as const };

  const type = TYPES.includes(String(body.type)) ? String(body.type) : "check";
  const weightNum = Number(body.weight);

  return {
    values: {
      section: String(body.section ?? "عام").trim().slice(0, 60) || "عام",
      title,
      type,
      weight: type === "note" ? 0 : Number.isFinite(weightNum) ? Math.min(5, Math.max(1, Math.trunc(weightNum))) : 1,
      required: body.required === undefined ? type !== "note" : Boolean(body.required),
      sortOrder: Number.isFinite(Number(body.sortOrder)) ? Math.max(0, Math.trunc(Number(body.sortOrder))) : 0,
      active: body.active === undefined ? true : Boolean(body.active),
    },
  };
}

export async function handle(req: Request, ctx: Ctx) {
  const param = String(ctx.params.id ?? "");
  const identity = identityOf(req);

  try {
    if (req.method === "GET") {
      let rows = await db.select().from(visitItems).orderBy(asc(visitItems.sortOrder), asc(visitItems.id));
      if (rows.length === 0) {
        await db.insert(visitItems).values(seedRows());
        rows = await db.select().from(visitItems).orderBy(asc(visitItems.sortOrder), asc(visitItems.id));
      }

      return Response.json(
        { items: rows, settings: await readSettings() },
        { headers: { "cache-control": "no-store" } },
      );
    }

    if (!isAdmin(identity)) {
      return Response.json({ error: "تعديل بنود الزيارة متاح لمدير النظام فقط" }, { status: 403 });
    }

    if (req.method === "PUT" && param === "settings") {
      const body = (await req.json()) as Record<string, unknown>;
      const perMonth = Number(body.visitsPerMonth);
      if (!Number.isFinite(perMonth) || perMonth < 1 || perMonth > 31) {
        return Response.json({ error: "عدد الزيارات الشهرية يجب أن يكون بين 1 و 31" }, { status: 400 });
      }

      await db
        .insert(appSettings)
        .values({ settingKey: VISITS_PER_MONTH_KEY, settingValue: String(Math.trunc(perMonth)) })
        .onConflictDoUpdate({
          target: appSettings.settingKey,
          set: { settingValue: String(Math.trunc(perMonth)), updatedAt: new Date() },
        });

      return Response.json({ settings: await readSettings() });
    }

    if (req.method === "POST") {
      const parsed = parseBody((await req.json()) as Record<string, unknown>);
      if ("error" in parsed) return Response.json({ error: parsed.error }, { status: 400 });

      const [created] = await db.insert(visitItems).values(parsed.values).returning();
      return Response.json({ item: created }, { status: 201 });
    }

    const id = Number(param);
    if (!id) return Response.json({ error: "معرّف البند مطلوب" }, { status: 400 });

    if (req.method === "PUT") {
      const parsed = parseBody((await req.json()) as Record<string, unknown>);
      if ("error" in parsed) return Response.json({ error: parsed.error }, { status: 400 });

      const [updated] = await db
        .update(visitItems)
        .set({ ...parsed.values, updatedAt: new Date() })
        .where(eq(visitItems.id, id))
        .returning();

      if (!updated) return Response.json({ error: "البند غير موجود" }, { status: 404 });
      return Response.json({ item: updated });
    }

    if (req.method === "DELETE") {
      const [deleted] = await db.delete(visitItems).where(eq(visitItems.id, id)).returning();
      if (!deleted) return Response.json({ error: "البند غير موجود" }, { status: 404 });
      return Response.json({ item: deleted });
    }

    return Response.json({ error: "طريقة غير مدعومة" }, { status: 405 });
  } catch (error) {
    console.error("visit-items failed", error);
    return Response.json({ error: "تعذّر تنفيذ الطلب" }, { status: 500 });
  }
}
