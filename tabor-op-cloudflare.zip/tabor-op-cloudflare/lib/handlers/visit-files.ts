import type { Ctx } from "../router.js";
import { asc, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { visitFiles } from "../../db/schema.js";
import { identityOf } from "../hierarchy.js";

/**
 * مرفقات الزيارة (صور/ملفات)
 *
 * GET /api/visit-files?visitId=12 → مرفقات زيارة واحدة بمحتواها (base64)
 *
 * المرفقات تُرفع مع التقرير نفسه عبر POST /api/visits، وتُقرأ من هنا فقط عند
 * فتح التقرير أو توليد ملف التقرير المُرسَل للمشرف — حتى لا تُحمَّل القوائم بالصور.
 */

export async function handle(req: Request, ctx: Ctx) {
  const identity = identityOf(req);
  if (!identity.role) {
    return Response.json({ error: "هوية المستخدم غير معروفة" }, { status: 401 });
  }

  try {
    const url = new URL(req.url);
    const visitId = Number(url.searchParams.get("visitId") ?? 0);
    if (!visitId) return Response.json({ error: "معرّف الزيارة مطلوب" }, { status: 400 });

    const rows = await db
      .select()
      .from(visitFiles)
      .where(eq(visitFiles.visitId, visitId))
      .orderBy(asc(visitFiles.id));

    return Response.json({ files: rows }, { headers: { "cache-control": "no-store" } });
  } catch (error) {
    console.error("visit-files failed", error);
    return Response.json({ error: "تعذّر تنفيذ الطلب" }, { status: 500 });
  }
}
