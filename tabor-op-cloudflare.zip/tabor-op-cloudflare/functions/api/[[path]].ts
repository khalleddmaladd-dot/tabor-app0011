import { route } from "../../lib/router.js";

/**
 * نقطة الدخول الوحيدة لكل مسارات /api/* في Cloudflare Pages Functions.
 * رابط قاعدة البيانات يُقرأ من متغيّرات البيئة المضبوطة في لوحة Cloudflare.
 */
export const onRequest = async (context: {
  request: Request;
  env: { DATABASE_URL?: string };
}) => route(context.request, context.env.DATABASE_URL ?? "");
