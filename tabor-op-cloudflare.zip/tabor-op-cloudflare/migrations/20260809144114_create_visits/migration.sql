CREATE TABLE "app_settings" (
	"id" serial PRIMARY KEY,
	"setting_key" text NOT NULL,
	"setting_value" text DEFAULT '' NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "visit_files" (
	"id" serial PRIMARY KEY,
	"visit_id" integer NOT NULL,
	"name" text DEFAULT 'مرفق' NOT NULL,
	"mime" text DEFAULT 'image/jpeg' NOT NULL,
	"size" integer DEFAULT 0 NOT NULL,
	"caption" text DEFAULT '' NOT NULL,
	"data" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "visit_items" (
	"id" serial PRIMARY KEY,
	"section" text DEFAULT 'عام' NOT NULL,
	"title" text NOT NULL,
	"type" text DEFAULT 'check' NOT NULL,
	"weight" integer DEFAULT 1 NOT NULL,
	"required" boolean DEFAULT false NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "visits" (
	"id" serial PRIMARY KEY,
	"branch_id" text NOT NULL,
	"branch_name" text DEFAULT '' NOT NULL,
	"region" text DEFAULT '' NOT NULL,
	"visitor_name" text DEFAULT '' NOT NULL,
	"visitor_role" text DEFAULT '' NOT NULL,
	"day" text NOT NULL,
	"month" text NOT NULL,
	"started_at" timestamp DEFAULT now() NOT NULL,
	"submitted_at" timestamp,
	"lat" double precision NOT NULL,
	"lng" double precision NOT NULL,
	"distance" integer DEFAULT 0 NOT NULL,
	"score" integer DEFAULT 0 NOT NULL,
	"results" text DEFAULT '[]' NOT NULL,
	"notes" text DEFAULT '' NOT NULL,
	"actions" text DEFAULT '' NOT NULL,
	"supervisor_name" text DEFAULT '' NOT NULL,
	"sent_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "app_settings_key_idx" ON "app_settings" ("setting_key");--> statement-breakpoint
CREATE INDEX "visit_files_visit_idx" ON "visit_files" ("visit_id");--> statement-breakpoint
CREATE INDEX "visit_items_order_idx" ON "visit_items" ("sort_order");--> statement-breakpoint
CREATE INDEX "visits_branch_month_idx" ON "visits" ("branch_id","month");--> statement-breakpoint
CREATE INDEX "visits_month_idx" ON "visits" ("month");