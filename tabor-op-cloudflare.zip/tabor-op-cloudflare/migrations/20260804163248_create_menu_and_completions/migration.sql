CREATE TABLE "menu_items" (
	"id" serial PRIMARY KEY,
	"item_key" text NOT NULL,
	"label" text NOT NULL,
	"roles" text DEFAULT '' NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "task_completions" (
	"id" serial PRIMARY KEY,
	"scope_id" text NOT NULL,
	"role" text NOT NULL,
	"task_id" text NOT NULL,
	"day" text NOT NULL,
	"done_by_name" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX "menu_items_key_idx" ON "menu_items" ("item_key");--> statement-breakpoint
CREATE UNIQUE INDEX "task_completions_unique_idx" ON "task_completions" ("scope_id","task_id","day");--> statement-breakpoint
CREATE INDEX "task_completions_day_idx" ON "task_completions" ("day");