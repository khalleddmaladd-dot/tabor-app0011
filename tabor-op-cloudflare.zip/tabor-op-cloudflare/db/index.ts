import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import * as schema from "./schema.js";

/**
 * الاتصال بقاعدة البيانات (Neon) عبر HTTP.
 *
 * في Cloudflare Workers لا يوجد `process.env`؛ الرابط يصل مع أول طلب عبر `env`
 * ثم يُحتفظ باتصال واحد داخل نفس العزلة (Isolate). الرابط ثابت لكل الطلبات
 * فلا خطر من مشاركته، ومشغّل Neon عبر HTTP بلا اتصال دائم مفتوح.
 */
function makeDb(url: string) {
  return drizzle({ client: neon(url), schema });
}

export type Db = ReturnType<typeof makeDb>;

let instance: Db | null = null;

export function initDb(url: string) {
  if (!url) throw new Error("DATABASE_URL غير مضبوط في إعدادات الموقع");
  if (!instance) instance = makeDb(url);
  return instance;
}

/** يستخدمها المعالجون مباشرة بعد تهيئتها في الموجّه */
export const db = new Proxy({} as Db, {
  get(_target, prop) {
    if (!instance) throw new Error("قاعدة البيانات لم تُهيّأ بعد");
    return (instance as never as Record<string | symbol, unknown>)[prop];
  },
});
