import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  doublePrecision,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * كتالوج التقارير المطلوبة — قابل للتعديل والإضافة من مدير النظام.
 *
 * القواعد الافتراضية للاستحقاق:
 *  - التقارير الأسبوعية: كل يوم سبت (due_weekday = 6)
 *  - التقارير الشهرية: يوم 5 من كل شهر (due_day = 5)
 *  - استثناء: جدول الدوام يوم 20 من كل شهر (due_day = 20)
 */
export const requiredReports = pgTable(
  "required_reports",
  {
    id: serial().primaryKey(),
    // المنصب المسؤول: ops_manager | area_manager | branch_manager | cashier
    role: text().notNull(),
    // التكرار: weekly | monthly
    frequency: text().notNull(),
    title: text().notNull(),
    icon: text().notNull().default("📄"),
    // يوم الأسبوع للتقارير الأسبوعية (0 = الأحد ... 6 = السبت)
    dueWeekday: integer("due_weekday").notNull().default(6),
    // يوم الشهر للتقارير الشهرية (1 - 31)
    dueDay: integer("due_day").notNull().default(5),
    notes: text().notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean().notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [index("required_reports_role_idx").on(table.role, table.frequency)],
);

/**
 * كتالوج المهام اليومية — قابل للتعديل والإضافة والحذف من مدير النظام فقط.
 *
 * كل مهمة مرتبطة بمنصب واحد (role) وتظهر لكل من يشغل هذا المنصب في خانة «مهامي».
 * الحقل `category` يُستخدم لتجميع المهام في مجموعات داخل الواجهة (تحسين العرض).
 */
export const dailyTasks = pgTable(
  "daily_tasks",
  {
    id: serial().primaryKey(),
    // المنصب المسؤول: ops_manager | area_manager | branch_manager | cashier
    role: text().notNull(),
    title: text().notNull(),
    icon: text().notNull().default("📌"),
    // تصنيف المهمة داخل قائمة المنصب (تشغيل / جودة / مبيعات / نظافة ...)
    category: text().notNull().default("عام"),
    // فترة التنفيذ المقترحة: anytime | morning | evening | closing
    period: text().notNull().default("anytime"),
    notes: text().notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean().notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [index("daily_tasks_role_idx").on(table.role, table.sortOrder)],
);

/**
 * المهام المستعجلة — تُوزَّع حسب التسلسل الوظيفي.
 *
 * مدير التشغيل → مدير المنطقة → مشرف الفرع → الكاشير
 * لا يستطيع أي مستخدم إسناد مهمة إلا لمنصب أدنى منه، وداخل نطاقه فقط
 * (مدير المنطقة داخل منطقته، ومشرف الفرع داخل فرعه).
 */
export const urgentTasks = pgTable(
  "urgent_tasks",
  {
    id: serial().primaryKey(),
    title: text().notNull(),
    details: text().notNull().default(""),
    // عالي | متوسط | منخفض
    priority: text().notNull().default("متوسط"),
    // جديد | قيد التنفيذ | مكتمل
    status: text().notNull().default("جديد"),
    // المنصب المُكلَّف (أدنى من منصب المُنشئ)
    targetRole: text("target_role").notNull(),
    // نطاق التكليف: فارغ = كل المناطق / كل الفروع
    region: text().notNull().default(""),
    branch: text().notNull().default(""),
    dueDate: text("due_date").notNull().default(""),
    createdByRole: text("created_by_role").notNull(),
    createdByName: text("created_by_name").notNull().default(""),
    updatedByName: text("updated_by_name").notNull().default(""),
    completedAt: timestamp("completed_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [index("urgent_tasks_target_idx").on(table.targetRole, table.status)],
);

/**
 * الفروع — لكل فرع موقع جغرافي إلزامي (lat/lng + نطاق بالمتر).
 *
 * الموقع هو ما يربط الفرع بجداول الدوام: تسجيل الحضور والانصراف يتحقق من
 * وجود الموظف داخل نطاق الفرع (Geofence) قبل اعتماد البصمة.
 */
export const branches = pgTable(
  "branches",
  {
    id: serial().primaryKey(),
    // المعرّف المستخدم في الواجهة وجداول الدوام (y1 / j2 / r3 ...)
    branchId: text("branch_id").notNull(),
    region: text().notNull(),
    name: text().notNull(),
    supervisor: text().notNull().default(""),
    // الموقع الجغرافي — إلزامي
    lat: doublePrecision().notNull(),
    lng: doublePrecision().notNull(),
    // نطاق تسجيل الحضور بالمتر
    radius: integer().notNull().default(150),
    active: boolean().notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [uniqueIndex("branches_branch_id_idx").on(table.branchId)],
);

/**
 * القائمة الرئيسية — ترتيب وتسمية وإظهار شاشات النظام.
 *
 * الشاشات نفسها ثابتة في التطبيق، وهذا الجدول يخزّن «التخصيص» فوقها:
 * الاسم المعروض، الترتيب، الإظهار/الإخفاء، والمناصب المسموح لها بالرؤية.
 */
export const menuItems = pgTable(
  "menu_items",
  {
    id: serial().primaryKey(),
    // معرّف الشاشة داخل التطبيق: dashboard | tasks | tracking | admin ...
    itemKey: text("item_key").notNull(),
    label: text().notNull(),
    // المناصب المسموح لها — مفصولة بفواصل، فارغ = الجميع
    roles: text().notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean().notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [uniqueIndex("menu_items_key_idx").on(table.itemKey)],
);

/**
 * إنجاز المهام اليومية — مصدر النسب والمؤشرات في «متابعة المرؤوسين».
 *
 * كل صف = مهمة أُنجزت في نطاق معيّن (فرع أو منطقة) بتاريخ معيّن.
 * حذف الصف = إلغاء الإنجاز. الحفظ على الخادم هو ما يجعل المدير يرى
 * إنجاز مرؤوسيه لحظياً بدل أن تبقى البيانات على جهاز كل مستخدم.
 */
export const taskCompletions = pgTable(
  "task_completions",
  {
    id: serial().primaryKey(),
    // نطاق التنفيذ: معرّف الفرع (j1) أو المنطقة لمدير المنطقة (jeddah) أو hq
    scopeId: text("scope_id").notNull(),
    role: text().notNull(),
    // معرّف المهمة كما يظهر في الواجهة (t12 أو db3)
    taskId: text("task_id").notNull(),
    day: text().notNull(),
    doneByName: text("done_by_name").notNull().default(""),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("task_completions_unique_idx").on(table.scopeId, table.taskId, table.day),
    index("task_completions_day_idx").on(table.day),
  ],
);

/**
 * إعدادات عامة (مفتاح/قيمة) — يعدّلها مدير النظام.
 * تُستخدم حالياً لعدد الزيارات الشهرية المطلوبة لكل فرع.
 */
export const appSettings = pgTable(
  "app_settings",
  {
    id: serial().primaryKey(),
    settingKey: text("setting_key").notNull(),
    settingValue: text("setting_value").notNull().default(""),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [uniqueIndex("app_settings_key_idx").on(table.settingKey)],
);

/**
 * بنود تقييم الزيارة — قابلة للإضافة والتعديل والحذف من مدير النظام.
 * type: check (مطابق/غير مطابق) | rating (1-5) | note (ملاحظة نصية غير محتسبة)
 */
export const visitItems = pgTable(
  "visit_items",
  {
    id: serial().primaryKey(),
    section: text().notNull().default("عام"),
    title: text().notNull(),
    type: text().notNull().default("check"),
    weight: integer().notNull().default(1),
    required: boolean().notNull().default(false),
    sortOrder: integer("sort_order").notNull().default(0),
    active: boolean().notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => [index("visit_items_order_idx").on(table.sortOrder)],
);

/**
 * زيارات الفروع.
 *
 * لا تُقبل الزيارة إلا من داخل نطاق الفرع الجغرافي: الخادم يتحقق من المسافة
 * بين إحداثيات كاتب التقرير وإحداثيات الفرع قبل الحفظ (نفس نطاق الحضور).
 * `results` لقطة JSON من بنود التقييم وقت الزيارة حتى تبقى التقارير القديمة صحيحة
 * حتى لو عُدّلت البنود لاحقاً.
 */
export const visits = pgTable(
  "visits",
  {
    id: serial().primaryKey(),
    branchId: text("branch_id").notNull(),
    branchName: text("branch_name").notNull().default(""),
    region: text().notNull().default(""),
    visitorName: text("visitor_name").notNull().default(""),
    visitorRole: text("visitor_role").notNull().default(""),
    day: text().notNull(),
    month: text().notNull(),
    // وقت الوصول ووقت اعتماد التقرير
    startedAt: timestamp("started_at").notNull().defaultNow(),
    submittedAt: timestamp("submitted_at"),
    // موقع كاتب التقرير وقت الحفظ + بعده عن الفرع بالأمتار
    lat: doublePrecision().notNull(),
    lng: doublePrecision().notNull(),
    distance: integer().notNull().default(0),
    score: integer().notNull().default(0),
    results: text().notNull().default("[]"),
    notes: text().notNull().default(""),
    // الإجراءات المتخذة — إلزامية عند الاعتماد
    actions: text().notNull().default(""),
    supervisorName: text("supervisor_name").notNull().default(""),
    sentAt: timestamp("sent_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => [
    index("visits_branch_month_idx").on(table.branchId, table.month),
    index("visits_month_idx").on(table.month),
  ],
);

/** مرفقات الزيارة — صور وملفات مضغوطة ومخزّنة مع التقرير */
export const visitFiles = pgTable(
  "visit_files",
  {
    id: serial().primaryKey(),
    visitId: integer("visit_id").notNull(),
    name: text().notNull().default("مرفق"),
    mime: text().notNull().default("image/jpeg"),
    size: integer().notNull().default(0),
    caption: text().notNull().default(""),
    // محتوى الملف بترميز base64
    data: text().notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => [index("visit_files_visit_idx").on(table.visitId)],
);
